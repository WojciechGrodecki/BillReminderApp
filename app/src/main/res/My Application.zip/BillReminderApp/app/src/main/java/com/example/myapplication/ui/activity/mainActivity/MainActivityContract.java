package com.example.myapplication.ui.activity.mainActivity;

public interface MainActivityContract {


    interface Presenter {

    }

    interface View {

    }
}