package com.example.myapplication.ui.fragments.allBills;

import com.example.myapplication.db.model.Bill;

public interface onBillItemClickListener {
    void onClick(Bill bill);
}
