package com.example.myapplication.ui.fragments.billPaid;

public interface BillPaidContract {


    interface Presenter {

    }

    interface View {

    }
}