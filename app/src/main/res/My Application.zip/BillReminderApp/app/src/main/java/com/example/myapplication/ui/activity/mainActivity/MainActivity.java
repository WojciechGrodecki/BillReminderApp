package com.example.myapplication.ui.activity.mainActivity;

import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.aurelhubert.ahbottomnavigation.AHBottomNavigation;
import com.aurelhubert.ahbottomnavigation.AHBottomNavigationItem;
import com.aurelhubert.ahbottomnavigation.AHBottomNavigationViewPager;
import com.example.myapplication.R;
import com.example.myapplication.ui.base.BaseActivity;
import com.example.myapplication.ui.fragments.addBill.AddBillFragment;
import com.example.myapplication.ui.fragments.allBills.AllBillsFragment;
import com.example.myapplication.ui.fragments.billUnPaid.BillUnPaidFragment;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends BaseActivity {
    private static final int MENU_COLOR = android.R.color.holo_green_light;
    private static final int PROFILE_COLOR = android.R.color.holo_purple;
    private static final int SETTINGS_COLOR = android.R.color.holo_red_light;
    private final MenuPagerAdapter mPagerAdapter = new MenuPagerAdapter(getSupportFragmentManager());

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment_animation);
        createBottomNavigation();
    }

    private void createBottomNavigation() {
        AHBottomNavigation bottomNavigation = findViewById(R.id.bnMain);
        AHBottomNavigationViewPager viewPager = findViewById(R.id.view_pager);

        AHBottomNavigationItem item1 = new AHBottomNavigationItem(R.string.navigation_tab_menu,
                R.drawable.outline_menu_white_24, MENU_COLOR);
        AHBottomNavigationItem item2 = new AHBottomNavigationItem(R.string.navigation_tab_profile,
                R.drawable.outline_face_white_24, PROFILE_COLOR);
        AHBottomNavigationItem item3 = new AHBottomNavigationItem(R.string.navigation_tab_settings,
                R.drawable.outline_settings_white_24, SETTINGS_COLOR);

        bottomNavigation.addItem(item1);
        bottomNavigation.addItem(item2);
        bottomNavigation.addItem(item3);

        bottomNavigation.setBehaviorTranslationEnabled(true);
        bottomNavigation.setColored(true);
        bottomNavigation.setAccentColor(ContextCompat.getColor(this, android.R.color.white));
        bottomNavigation.setInactiveColor(ContextCompat.getColor(this, android.R.color.darker_gray));
        bottomNavigation.setNotificationTextColor(ContextCompat.getColor(this, android.R.color.white));
        bottomNavigation.setNotificationBackgroundColor(ContextCompat.getColor(this, android.R.color.holo_red_dark));

        bottomNavigation.setOnTabSelectedListener((position, wasSelected) -> {
            if (!wasSelected) {
                changeColors(position);
                viewPager.setCurrentItem(position, false);
            }
            return true;
        });

        viewPager.setOffscreenPageLimit(mPagerAdapter.getCount());
        viewPager.setAdapter(mPagerAdapter);
        changeColors(0);
    }

    private void changeColors(int position) {
        int color = 0;
        switch (position) {
            case 0:
                color = MENU_COLOR;
                break;
            case 1:
                color = PROFILE_COLOR;
                break;
            case 2:
                color = SETTINGS_COLOR;
                break;
        }
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources()
                .getColor(color)));
        Window window = getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(ContextCompat.getColor(this, color));
    }

    public class MenuPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragments = new ArrayList<>();
        private Fragment mCurrentFragment;

        /* package */ MenuPagerAdapter(@NonNull FragmentManager fragmentManager) {
            super(fragmentManager);

            mFragments.clear();
            mFragments.add(new AllBillsFragment());
            mFragments.add(new AddBillFragment());
            mFragments.add(new BillUnPaidFragment());
        }

        @Override
        public Fragment getItem(int position) {
            return mFragments.get(position);
        }

        @Override
        public int getCount() {
            return mFragments.size();
        }

        @Override
        public void setPrimaryItem(ViewGroup container, int position, Object object) {
            if (getCurrentFragment() != object) {
                mCurrentFragment = (Fragment) object;
            }

            super.setPrimaryItem(container, position, object);
        }

        private @NonNull
        Fragment getCurrentFragment() {
            return mCurrentFragment;
        }
    }

}
